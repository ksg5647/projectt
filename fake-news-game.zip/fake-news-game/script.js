/* =========================================================
   진짜? 가짜? — 가짜뉴스·딥페이크 판별 게임
   ---------------------------------------------------------
   ※ 모든 문제는 학습용으로 만든 가상의 예시입니다.
     실제 기사나 실존 인물이 아닙니다.
   ========================================================= */


/* =========================================================
   1) 문제 데이터
   ---------------------------------------------------------
   type    : "news"(기사) 또는 "image"(사진·영상)
   isFake  : true면 가짜, false면 진짜
   reason  : 왜 가짜/진짜인지 설명
   signals : 판별 단서 태그
   ========================================================= */
const questions = [

  /* ---------- 뉴스 기사 ---------- */
  {
    type: "news",
    title: "충격! 하루 커피 3잔이면 수명 10년 늘어난다",
    body: "국제건강수명연구소가 발표한 자료에 따르면, 매일 커피를 3잔씩 마신 사람은 그렇지 않은 사람보다 평균 10년 더 오래 산 것으로 나타났다. 연구소 측은 \"커피가 노화를 완전히 멈춘다\"고 밝혔다.",
    meta: "출처: 온라인 커뮤니티 공유글",
    isFake: true,
    reason: "'국제건강수명연구소'는 검색해도 나오지 않는 존재하지 않는 기관입니다. 게다가 '수명 10년', '노화를 완전히 멈춘다' 같은 표현은 과학에서 절대 쓰지 않는 단정입니다. 진짜 연구는 '~와 관련이 있을 수 있다' 정도로 조심스럽게 말합니다.",
    signals: ["존재하지 않는 기관", "비현실적 수치", "'충격!' 자극적 제목", "단정적 표현"]
  },
  {
    type: "news",
    title: "교육부, 대입 제도 개편안 공청회 개최",
    body: "교육부는 대입 제도 개편 방안에 대한 의견 수렴을 위해 공청회를 연다고 밝혔다. 공청회 자료는 교육부 누리집에서 확인할 수 있으며, 온라인 중계도 함께 진행된다.",
    meta: "출처: 교육부 보도자료 / 담당 부서·연락처 명시",
    isFake: false,
    reason: "제목이 담백하고, 발표 주체(교육부)가 분명하며, 원문을 직접 확인할 수 있는 경로(누리집, 보도자료)를 제시합니다. 진짜 기사는 '확인해보라'고 당당하게 말합니다.",
    signals: ["출처 명확", "확인 가능한 경로", "담백한 제목"]
  },
  {
    type: "news",
    title: "속보!! 내일부터 전국 모든 학교 전면 휴교!! 지금 바로 공유하세요!!!",
    body: "정부 고위 관계자에 따르면 내일부터 전국 학교가 문을 닫는다고 합니다. 아직 언론에는 안 나왔습니다. 아는 사람만 아는 정보! 가족 단톡방에 꼭 공유해주세요!!",
    meta: "출처: 없음 (메신저로 전달받음)",
    isFake: true,
    reason: "'아직 언론에 안 나왔다'는 말은 가짜뉴스의 대표적인 자기 변명입니다. 전국 휴교처럼 큰 일이면 모든 언론사가 동시에 보도합니다. '지금 바로 공유하세요'는 검증할 시간을 주지 않으려는 전형적인 수법이에요.",
    signals: ["공유 재촉", "느낌표 남발", "출처 없음", "'언론에 안 나온 정보'"]
  },
  {
    type: "news",
    title: "익명의 정부 관계자 \"내년부터 청소년 스마트폰 사용시간 국가가 강제 제한\"",
    body: "이름을 밝히기를 거부한 한 정부 관계자는 \"내년부터 만 18세 미만의 스마트폰 사용이 하루 2시간으로 제한될 것\"이라고 전했다. 해당 부처는 아직 공식 입장을 내지 않았다.",
    meta: "출처: 익명의 관계자",
    isFake: true,
    reason: "'익명의 관계자'만 등장하고 확인 가능한 근거가 하나도 없습니다. 이런 제도는 법을 바꿔야 하는 일이라 반드시 입법예고·공청회 같은 공개 절차를 거칩니다. 절차 없이 '내년부터 시행'은 성립하지 않아요.",
    signals: ["익명 출처", "검증 불가", "공식 입장 없음"]
  },
  {
    type: "news",
    title: "기상청, 수도권 호우주의보 발효",
    body: "기상청은 오늘 오후 수도권 일부 지역에 호우주의보를 발효했다고 밝혔다. 시간당 20mm 안팎의 비가 예상되며, 자세한 정보는 기상청 날씨누리에서 확인할 수 있다.",
    meta: "출처: 기상청 / 실시간 확인 가능",
    isFake: false,
    reason: "구체적인 수치(시간당 20mm)를 제시하고, 누구나 지금 당장 원본을 확인할 수 있는 곳(기상청)을 알려줍니다. 과장된 감정 표현이 전혀 없다는 점도 신뢰 신호입니다.",
    signals: ["공식 기관", "구체적 수치", "실시간 검증 가능"]
  },
  {
    type: "news",
    title: "의사들이 숨기는 진실 — 이 과일 하나면 모든 병이 낫는다",
    body: "병원에서는 절대 알려주지 않는 비밀. 이 과일을 아침마다 먹은 사람들은 당뇨, 고혈압, 암까지 모두 나았다고 증언한다. 제약회사가 이 사실이 알려지는 것을 막고 있다.",
    meta: "출처: 건강정보 블로그",
    isFake: true,
    reason: "'의사들이 숨긴다', '제약회사가 막는다'는 음모론 프레임입니다. 근거를 못 대는 대신 '숨겨져 있어서 근거가 없는 것'이라고 둘러대는 수법이죠. 하나로 모든 병을 고치는 것은 존재하지 않습니다.",
    signals: ["음모론 프레임", "만병통치 주장", "개인 증언만 존재", "근거 없음"]
  },
  {
    type: "news",
    title: "통계청, 지난달 소비자물가 상승률 발표",
    body: "통계청이 발표한 소비자물가동향에 따르면 지난달 물가는 1년 전 같은 달보다 상승했다. 품목별 세부 자료는 국가통계포털(KOSIS)에서 내려받을 수 있다.",
    meta: "출처: 통계청 / 원자료 공개",
    isFake: false,
    reason: "발표 기관이 명확하고, 원본 데이터를 직접 내려받아 검증할 수 있게 열어둡니다. '원자료를 공개한다'는 건 가짜뉴스가 절대 못 하는 일이에요.",
    signals: ["공식 통계", "원자료 공개", "검증 가능"]
  },
  {
    type: "news",
    title: "전문가 경고 \"2027년까지 모든 직업이 AI로 100% 대체된다\"",
    body: "한 AI 전문가는 \"2027년이면 인간이 하는 모든 일이 사라진다\"며 \"지금 공부하는 것은 의미가 없다\"고 경고했다. 이 전문가의 소속과 이름은 알려지지 않았다.",
    meta: "출처: 이름 없는 '전문가'",
    isFake: true,
    reason: "'모든', '100%' 같은 극단적 일반화는 가짜뉴스의 지문입니다. 게다가 전문가의 이름도 소속도 없어요. 실제 연구는 '일부 직무가 변화할 수 있다'처럼 범위를 좁혀서 말합니다.",
    signals: ["극단적 일반화", "무명 전문가", "공포 조성", "'100%' 단정"]
  },
  {
    type: "news",
    title: "서울시, 청소년 교통비 지원 신청 접수",
    body: "서울시는 청소년 교통비 지원 사업 신청을 받는다고 밝혔다. 신청 자격과 방법은 서울시 누리집 공고문에 안내되어 있으며, 문의는 다산콜센터로 하면 된다.",
    meta: "출처: 서울시 공고 / 문의처 명시",
    isFake: false,
    reason: "공고문 원문이 있고, 물어볼 전화번호까지 있습니다. 가짜뉴스는 '어디에 물어보라'는 말을 절대 못 씁니다. 물어보면 들통나니까요.",
    signals: ["공고 원문 존재", "문의처 명시", "확인 가능"]
  },

  /* ---------- 사진 · 영상 ---------- */
  {
    type: "image",
    emoji: "🎥",
    caption: "한 정치인이 연설하는 30초짜리 영상. 화질은 꽤 좋아 보인다.",
    details: [
      "말할 때 입 주변만 살짝 흐릿하게 뭉개진다",
      "목소리와 입 모양이 약 0.2초 어긋난다",
      "고개를 옆으로 돌릴 때 턱선이 순간 일그러진다"
    ],
    isFake: true,
    reason: "딥페이크는 보통 '얼굴 전체'가 아니라 '입 주변'만 바꿉니다. 그래서 입 주변만 화질이 다르고, 음성 싱크가 미세하게 어긋나요. 고개를 돌리는 순간은 AI가 가장 어려워하는 구간이라 여기서 무너집니다.",
    signals: ["입 주변만 흐림", "음성 싱크 어긋남", "고개 돌릴 때 왜곡"]
  },
  {
    type: "image",
    emoji: "🎤",
    caption: "야외 콘서트 사진. 무대 위 가수와 관객들이 함께 찍혔다.",
    details: [
      "무대 조명 방향과 모든 사람의 그림자 방향이 일치한다",
      "뒤쪽 관객 얼굴은 자연스럽게 초점이 나가 있다",
      "머리카락 한 올 한 올이 배경과 깔끔하게 구분된다"
    ],
    isFake: false,
    reason: "빛의 방향과 그림자가 전부 일치하는 건 AI가 가장 어려워하는 부분입니다. 또 진짜 카메라는 거리에 따라 초점이 자연스럽게 흐려지는데, 이 '거리감'을 AI는 잘 못 만듭니다.",
    signals: ["조명·그림자 일치", "자연스러운 초점", "머리카락 경계 선명"]
  },
  {
    type: "image",
    emoji: "🕶️",
    caption: "한 인물의 상반신 프로필 사진. 언뜻 보면 아주 자연스럽다.",
    details: [
      "안경테가 왼쪽은 두껍고 오른쪽은 얇다",
      "귀걸이가 한쪽에만 달려 있다",
      "옷깃 무늬가 어깨에서 갑자기 끊긴다"
    ],
    isFake: true,
    reason: "AI는 '좌우 대칭'을 잘 못 지킵니다. 안경, 귀걸이, 단추, 무늬처럼 짝이 맞아야 하는 것들을 먼저 보세요. 얼굴은 그럴듯한데 액세서리가 짝짝이라면 거의 확실합니다.",
    signals: ["좌우 비대칭", "액세서리 짝 안 맞음", "무늬 끊김"]
  },
  {
    type: "image",
    emoji: "✋",
    caption: "카페에서 책을 읽고 있는 사람의 사진.",
    details: [
      "책을 든 손의 손가락이 여섯 개다",
      "뒤쪽 간판 글자가 글자처럼 생겼지만 읽을 수 없다",
      "책 표지의 글씨도 뭉개져 있다"
    ],
    isFake: true,
    reason: "손가락과 글자는 AI 생성 이미지의 2대 약점입니다. AI는 '글자처럼 생긴 무늬'를 그릴 뿐 실제 글자를 쓰지 못해요. 사진 속 간판·표지·번호판을 확대해서 읽어보는 게 가장 빠른 판별법입니다.",
    signals: ["손가락 개수 이상", "글자가 읽히지 않음", "AI 생성 흔적"]
  },
  {
    type: "image",
    emoji: "📷",
    caption: "사건 현장을 찍은 보도 사진. 신문 기사에 함께 실렸다.",
    details: [
      "사진 아래에 촬영 기자 이름과 촬영 날짜가 적혀 있다",
      "같은 현장을 다른 각도에서 찍은 사진이 여러 장 있다",
      "다른 언론사도 같은 현장 사진을 보도했다"
    ],
    isFake: false,
    reason: "가장 강력한 검증은 이미지 자체가 아니라 '주변 정보'입니다. 촬영자가 누구인지, 같은 장면이 여러 각도로 존재하는지, 다른 곳에서도 다뤘는지. 딥페이크는 보통 딱 한 장, 출처 없이 돌아다닙니다.",
    signals: ["촬영자 명시", "여러 각도 존재", "복수 언론 확인"]
  },
  {
    type: "image",
    emoji: "💡",
    caption: "실내에서 찍은 인물 사진. 표정이 아주 선명하다.",
    details: [
      "얼굴에는 정면에서 밝은 빛이 들어온다",
      "그런데 뒤쪽 벽 그림자는 뒤에서 빛이 온 방향으로 져 있다",
      "인물 목 뒤쪽에만 그림자가 없다"
    ],
    isFake: true,
    reason: "빛은 거짓말을 못 합니다. 얼굴에 오는 빛의 방향과 배경 그림자의 방향이 다르면 두 이미지를 합성했다는 뜻이에요. 사람 얼굴부터 보지 말고 **그림자가 어디로 지는지**부터 보세요.",
    signals: ["조명 방향 불일치", "그림자 모순", "합성 흔적"]
  },
  {
    type: "image",
    emoji: "👁️",
    caption: "한 인물이 카메라를 보며 40초 동안 이야기하는 영상.",
    details: [
      "40초 동안 눈을 한 번도 깜빡이지 않는다",
      "눈동자가 늘 정확히 정면만 본다",
      "표정이 바뀔 때 볼 근육이 함께 움직이지 않는다"
    ],
    isFake: true,
    reason: "사람은 보통 1분에 15~20번 눈을 깜빡입니다. 40초 동안 한 번도 안 깜빡이는 건 불가능해요. 초기 딥페이크의 대표적 약점이었고, 지금도 '표정은 바뀌는데 근육은 안 움직이는' 어색함은 남아 있습니다.",
    signals: ["눈 깜빡임 없음", "눈동자 고정", "표정과 근육 불일치"]
  },
  {
    type: "image",
    emoji: "👨‍👩‍👧",
    caption: "가족이 함께 찍은 일상 사진.",
    details: [
      "세 사람의 피부톤이 목과 얼굴에서 자연스럽게 이어진다",
      "머리카락이 배경과 겹치는 부분도 한 올씩 구분된다",
      "각자 눈을 감은 정도가 미묘하게 다르다"
    ],
    isFake: false,
    reason: "'약간의 불완전함'이 오히려 진짜의 증거입니다. 누군가는 눈을 반쯤 감고, 누군가는 살짝 흔들려 있죠. AI 이미지는 이상하게 모두가 완벽하게 정면을 봅니다.",
    signals: ["피부톤 자연 연결", "머리카락 디테일", "자연스러운 불완전함"]
  },
  {
    type: "image",
    emoji: "🧣",
    caption: "인터뷰 중인 인물의 클로즈업 사진.",
    details: [
      "얼굴은 밝은 톤인데 목은 확실히 어둡다",
      "턱선을 따라 희미한 경계선이 보인다",
      "확대하면 얼굴 부분만 화질이 더 부드럽다"
    ],
    isFake: true,
    reason: "얼굴만 바꿔치기하면 원래 몸의 피부톤과 안 맞습니다. 그래서 턱선에 '이어붙인 자국'이 남아요. 딥페이크를 볼 땐 얼굴이 아니라 **얼굴과 목이 만나는 경계**를 보세요. 거기가 제일 약합니다.",
    signals: ["얼굴·목 피부톤 차이", "턱선 경계선", "부분 화질 차이"]
  }
];


/* =========================================================
   2) 체크리스트 데이터 (학습 화면)
   ========================================================= */
const newsChecklist = [
  { t: "제목이 나를 흥분시키는가?", d: "'충격', '경악', '속보!!' — 감정을 먼저 건드리면 판단력이 떨어집니다. 그게 목적이에요." },
  { t: "출처를 클릭할 수 있는가?", d: "'한 관계자', '익명의 전문가'만 있고 이름·소속·원문 링크가 없으면 의심하세요." },
  { t: "공유를 재촉하는가?", d: "'지금 바로 공유', '삭제되기 전에' — 확인할 시간을 뺏으려는 문장입니다." },
  { t: "다른 언론사에도 나오는가?", d: "핵심 단어만 검색해보세요. 큰 사건인데 한 곳에만 있다면 거의 가짜입니다." },
  { t: "'모든', '100%', '절대'를 쓰는가?", d: "진짜 연구·보도는 조심스럽게 범위를 좁혀 말합니다. 단정은 위험 신호예요." },
  { t: "숨겨진 진실 프레임인가?", d: "'의사가 숨긴다', '언론이 감춘다' — 근거가 없는 걸 정당화하는 전형적 수법입니다." },
  { t: "날짜가 적혀 있는가?", d: "오래된 사건을 날짜만 지우고 지금 일처럼 다시 퍼뜨리는 경우가 정말 많습니다." }
];

const imageChecklist = [
  { t: "손가락을 세어봤는가?", d: "AI는 아직도 손을 잘 못 그립니다. 손가락 개수, 관절 방향부터 확인하세요." },
  { t: "글자를 읽을 수 있는가?", d: "간판·책 표지·번호판을 확대해보세요. 글자처럼 생겼는데 안 읽히면 AI 생성입니다." },
  { t: "그림자 방향이 일치하는가?", d: "얼굴에 오는 빛과 배경 그림자의 방향이 다르면 합성입니다. 빛은 거짓말을 못 해요." },
  { t: "좌우가 대칭인가?", d: "안경테, 귀걸이, 단추, 옷 무늬. 짝이 맞아야 할 것들이 짝짝이면 의심하세요." },
  { t: "얼굴과 목의 경계를 봤는가?", d: "딥페이크는 얼굴만 바꿉니다. 턱선의 경계, 얼굴과 목의 피부톤 차이를 보세요." },
  { t: "영상에서 눈을 깜빡이는가?", d: "사람은 1분에 15~20번 깜빡입니다. 너무 안 깜빡여도, 너무 자주 깜빡여도 이상합니다." },
  { t: "이 이미지가 원래 어디서 왔는가?", d: "이미지 역검색을 해보세요. 몇 년 전 다른 사건 사진을 그대로 가져온 경우가 많습니다." }
];


/* =========================================================
   3) 게임 상태
   ========================================================= */
let order = [];       // 섞인 문제 순서
let index = 0;        // 현재 문제 번호
let score = 0;        // 맞힌 개수
let answered = false; // 이번 문제에 답했는지
let wrongList = [];   // 틀린 문제 모음
let stats = { news: { correct: 0, total: 0 }, image: { correct: 0, total: 0 } };


/* =========================================================
   4) 화면 요소 가져오기
   ========================================================= */
const $ = (id) => document.getElementById(id);

const screens = {
  start:  $("screen-start"),
  game:   $("screen-game"),
  result: $("screen-result"),
  learn:  $("screen-learn")
};


/* =========================================================
   5) 기본 기능 함수
   ========================================================= */

// 화면 전환
function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove("active"));
  screens[name].classList.add("active");
  window.scrollTo(0, 0);
}

// 배열 섞기 (피셔–예이츠 셔플)
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}


/* =========================================================
   6) 게임 진행
   ========================================================= */

function startGame() {
  order = shuffle(questions.map((_, i) => i));
  index = 0;
  score = 0;
  wrongList = [];
  stats = { news: { correct: 0, total: 0 }, image: { correct: 0, total: 0 } };
  showScreen("game");
  renderQuestion();
}

function currentQuestion() {
  return questions[order[index]];
}

function renderQuestion() {
  const q = currentQuestion();
  answered = false;

  // 진행 상황
  $("progress-text").textContent = `${index + 1} / ${order.length}`;
  $("progress-fill").style.width = `${(index / order.length) * 100}%`;
  $("score-text").textContent = score;

  // 해설 숨기고 답변 버튼 다시 보이기
  $("feedback").classList.add("hidden");
  $("answer-buttons").classList.remove("hidden");

  if (q.type === "news") {
    $("q-type").textContent = "📰 뉴스 기사";
    $("q-news").classList.remove("hidden");
    $("q-image").classList.add("hidden");

    $("news-title").textContent = q.title;
    $("news-body").textContent = q.body;
    $("news-meta").textContent = q.meta;
  } else {
    $("q-type").textContent = "🖼️ 사진 · 영상";
    $("q-image").classList.remove("hidden");
    $("q-news").classList.add("hidden");

    $("photo-emoji").textContent = q.emoji;
    $("photo-caption").textContent = q.caption;

    const ul = $("photo-details");
    ul.innerHTML = "";
    q.details.forEach(d => {
      const li = document.createElement("li");
      li.textContent = d;
      ul.appendChild(li);
    });
  }
}

// 답변 처리
function handleAnswer(userSaysFake) {
  if (answered) return;
  answered = true;

  const q = currentQuestion();
  const isCorrect = (userSaysFake === q.isFake);

  // 통계 기록
  stats[q.type].total++;
  if (isCorrect) {
    score++;
    stats[q.type].correct++;
  } else {
    wrongList.push(q);
  }

  // 해설 표시
  const head = $("feedback-head");
  const label = q.isFake ? "가짜" : "진짜";

  if (isCorrect) {
    head.textContent = `⭕ 정답! 이건 ${label}입니다.`;
    head.className = "feedback-head correct";
  } else {
    head.textContent = `❌ 아쉬워요. 이건 ${label}입니다.`;
    head.className = "feedback-head wrong";
  }

  $("feedback-reason").textContent = q.reason;
  $("signal-title").textContent = q.isFake
    ? "🚩 이 문제에 숨어 있던 가짜 신호"
    : "✅ 이 문제의 신뢰 신호";

  const tagBox = $("signal-tags");
  tagBox.innerHTML = "";
  q.signals.forEach(s => {
    const span = document.createElement("span");
    span.className = "tag";
    span.textContent = s;
    tagBox.appendChild(span);
  });

  $("btn-next").textContent =
    (index === order.length - 1) ? "결과 보기 →" : "다음 문제 →";

  $("answer-buttons").classList.add("hidden");
  $("feedback").classList.remove("hidden");
  $("score-text").textContent = score;
}

function nextQuestion() {
  index++;
  if (index >= order.length) {
    showResult();
  } else {
    renderQuestion();
  }
}


/* =========================================================
   7) 결과 화면
   ========================================================= */

function showResult() {
  const total = order.length;
  const percent = Math.round((score / total) * 100);

  let emoji, grade, comment;
  if (percent >= 90) {
    emoji = "🥇"; grade = "판별 전문가";
    comment = "거의 다 잡아냈네요! 이제 주변 사람들에게 알려줄 차례입니다.";
  } else if (percent >= 70) {
    emoji = "🥈"; grade = "훈련된 눈";
    comment = "감이 좋습니다. 놓친 문제의 단서만 익히면 거의 완벽해요.";
  } else if (percent >= 50) {
    emoji = "🥉"; grade = "성장 중";
    comment = "절반은 잡았어요. 아래 판별법을 익히면 확 올라갑니다.";
  } else {
    emoji = "🌱"; grade = "이제 시작";
    comment = "괜찮아요. 사실 대부분의 어른도 이 점수가 나옵니다. 그래서 배우는 거예요.";
  }

  $("result-emoji").textContent = emoji;
  $("result-grade").textContent = grade;
  $("result-score").textContent = percent;
  $("result-comment").textContent = comment;

  // 유형별 정답률
  const newsPct  = stats.news.total  ? Math.round(stats.news.correct  / stats.news.total  * 100) : 0;
  const imagePct = stats.image.total ? Math.round(stats.image.correct / stats.image.total * 100) : 0;

  $("rb-news-num").textContent  = `${stats.news.correct} / ${stats.news.total}`;
  $("rb-image-num").textContent = `${stats.image.correct} / ${stats.image.total}`;
  $("rb-news").style.width  = newsPct + "%";
  $("rb-image").style.width = imagePct + "%";

  // 틀린 문제 정리
  const box = $("wrong-box");
  const list = $("wrong-list");
  list.innerHTML = "";

  if (wrongList.length === 0) {
    box.classList.add("hidden");
  } else {
    box.classList.remove("hidden");
    wrongList.forEach(q => {
      const li = document.createElement("li");
      const name = q.type === "news" ? q.title : q.caption;
      li.innerHTML = `<b>${q.isFake ? "🚫 가짜" : "✅ 진짜"}</b> — ${name}<br />
                      <span style="color:var(--muted)">놓친 단서: ${q.signals.join(", ")}</span>`;
      list.appendChild(li);
    });
  }

  $("learn-score").textContent = percent;
  showScreen("result");
}


/* =========================================================
   8) 학습 화면 (체크리스트)
   ========================================================= */

function buildChecklist(containerId, items) {
  const box = $(containerId);
  box.innerHTML = "";

  items.forEach(item => {
    const div = document.createElement("div");
    div.className = "check-item";
    div.innerHTML = `
      <div class="check-box">✓</div>
      <div class="check-text">
        <b>${item.t}</b>
        <p>${item.d}</p>
      </div>`;

    div.addEventListener("click", () => {
      div.classList.toggle("checked");
      updateCheckCount();
    });

    box.appendChild(div);
  });
}

function updateCheckCount() {
  const n = document.querySelectorAll(".check-item.checked").length;
  $("check-count").textContent = n;
}

function showLearn() {
  showScreen("learn");
}


/* =========================================================
   9) 버튼 연결 & 시작
   ========================================================= */

document.querySelectorAll("[data-answer]").forEach(btn => {
  btn.addEventListener("click", () => {
    handleAnswer(btn.dataset.answer === "fake");
  });
});

$("btn-start").addEventListener("click", startGame);
$("btn-next").addEventListener("click", nextQuestion);
$("btn-to-learn").addEventListener("click", showLearn);
$("btn-retry").addEventListener("click", startGame);
$("btn-restart").addEventListener("click", startGame);
$("btn-skip-to-learn").addEventListener("click", showLearn);

// 시작 화면 숫자 채우기
$("start-total").textContent = questions.length;
$("start-news").textContent  = questions.filter(q => q.type === "news").length;
$("start-image").textContent = questions.filter(q => q.type === "image").length;

// 체크리스트 만들어두기
buildChecklist("check-news", newsChecklist);
buildChecklist("check-image", imageChecklist);
